fun main() {
    var animal: Cachorro = Cachorro("Poodle", "Lessi", 3)
    var ret = animal.getAnimal()
    println(ret)
    println()
    println(animal.getAnimal2())
}
