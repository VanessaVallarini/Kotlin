class Funcionario {

    var nome: String
    var numeroDeRegistro: Int

    constructor(nome: String, numeroDeRegistro: Int){
        this.nome = nome
        this.numeroDeRegistro = numeroDeRegistro
    }

    fun equals1(listaFuncionarios: MutableList<Funcionario>, numeroDeRegistro: Int): Boolean{
        var ret = false
        for(c in listaFuncionarios){
            if(c.numeroDeRegistro === numeroDeRegistro){
                ret = true
            }
        }
        return ret
    }

    fun equals2(listaAlunos: MutableList<Funcionario>, numeroDeRegistro: Int): Boolean{
        var ret = false
        for(c in listaAlunos){
            if(c.numeroDeRegistro.equals(numeroDeRegistro)){
                ret = true
            }
        }
        return ret
    }

    fun equals3(listaAlunos: MutableList<Funcionario>, funcionario: Funcionario): Boolean{
        var ret = false
        for(c in listaAlunos){
            if(c === funcionario){
                ret = true
            }
        }
        return ret
    }

    fun equals4(listaAlunos: MutableList<Funcionario>, funcionario: Funcionario): Boolean{
        var ret = false
        for(c in listaAlunos){
            if(c.equals(funcionario)){
                ret = true
            }
        }
        return ret
    }

}