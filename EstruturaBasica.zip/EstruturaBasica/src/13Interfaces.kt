fun main(){//servem como um contrato onde a classe que a implementa deve sobrescrever todos os métodos

    var bichinho: Bichinho = Bichinho()

    println(bichinho.tomarMedicamento())
}