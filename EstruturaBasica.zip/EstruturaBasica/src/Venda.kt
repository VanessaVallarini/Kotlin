class Venda {

    var valor: Double

    var veiculo: Veiculo

    var cliente: Cliente

    constructor(valor: Double, veiculo: Veiculo, cliente: Cliente){
        this.valor = valor
        this.veiculo = veiculo
        this.cliente = cliente
    }
}