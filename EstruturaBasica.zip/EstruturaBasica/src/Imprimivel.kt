interface Imprimivel {

    var nome: String
    var tipoDocumento: String

    fun imprimir(): String
}