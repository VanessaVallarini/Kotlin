import javax.print.attribute.standard.MediaSize

public class Pessoa {

    var nome: String
    var rg: Int

    constructor(nome: String, rg: Int){
        this.nome = nome
        this.rg = rg
    }

    override fun equals(other: Any?): Boolean{
        return this === other
    }

    fun equals(other: Int): Boolean{
        return this.rg === other
    }

    fun hashCode(pessoa: Pessoa): Int{
        return pessoa.hashCode()
    }

    override fun toString(): String{
        return "Nome: ${this.nome}\n" +
                "RG: ${this.rg}"
    }
}