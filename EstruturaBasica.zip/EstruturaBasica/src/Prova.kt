class Prova {

    private var dificuldade: Int = 0

    private var energiaNecessaria: Int = 0

    constructor(dificuldade: Int, energiaNecessaria: Int){
        this.dificuldade = dificuldade
        this.energiaNecessaria = energiaNecessaria
    }

    fun podeRealizar(atleta: Atleta): Boolean{
        if(atleta.getNivel() >= dificuldade && atleta.getEnergia() >= energiaNecessaria){
            return true
        }
        return false
    }
}