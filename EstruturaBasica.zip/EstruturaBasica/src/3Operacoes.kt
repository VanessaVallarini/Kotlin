fun main(){

    //Aritméticas

    var soma = 1 + 1
    var subtracao = 2 - 1
    var multiplicacao = 2 * 2
    var divisao = 2 / 2
    var restoDivisao : Double = 7.toDouble() % 2.toDouble()

    //Incremento e Decremento

    var incremento = ++soma
    var decremento = --subtracao

    println("Soma: 1 + 1 =              " + soma)
    println("Subtracao: 2 - 1 =         " + subtracao)
    println("Multiplicacao: 2 * 2 =     " + multiplicacao)
    println("Divisao: 2 / 2 =           " + divisao)
    println("RestoDivisao: 7 % 2 =       " + restoDivisao.toDouble())
    println("Incremento: ++soma =       " + incremento)
    println("Decremento: --subtracao =  " + decremento)

}