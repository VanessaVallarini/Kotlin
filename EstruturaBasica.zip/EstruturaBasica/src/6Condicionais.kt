fun main(){

    val numero = 2

    //if else
    if(numero == 1){
        println("UM")
    } else if(numero == 2){
        println("DOIS")
    } else if(numero == 3 || numero == 4){
        println("É TRÊS OU QUATRO")
    } else {
        println("É MAIOR QUE QUATRO")
    }

    //WHEN (CASE DO C#)
    when(numero){
        1 -> println("UM")
        2 -> println("DOIS")
        3,4 -> println("É TRÊS OU QUATRO")
        else -> {
            println("É MAIOR QUE QUATRO")
        }
    }
}