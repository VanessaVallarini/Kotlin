class SessaoDeTreinamento(var experiencia: Int) {

    fun treinarA(jogadorDeFutebol: JogadorDeFutebol){
        while (experiencia > 0){
            jogadorDeFutebol.correr()
            jogadorDeFutebol.fazerGol()
            jogadorDeFutebol.correr()
            jogadorDeFutebol.setExperiencia()
            --experiencia
            println()
        }
    }
}