class Car {

    //propriedade
    private var color: String = ""
    private var ano: Int = 0

    //métodos
    fun openWindow(){
        println("Open Window")
    }

    //chamar outro método da mesma classe
    fun openWindow2(){
        this.openWindow()
    }

    fun setAno(ano: Int){
        this.ano = ano
    }

    fun setColor(color: String){
        this.color = color
    }

    override fun toString(): String {
        return "Ano: $ano , Cor: $color"
    }


}