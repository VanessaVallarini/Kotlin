class Aula: IAula {

    private var materia: Materia
    private var horarioInicio: String
    private var horarioTermino: String

    constructor(materia: Materia, horarioInicio: String, horarioTermino: String){
        this.materia = materia
        this.horarioInicio = horarioInicio
        this.horarioTermino = horarioTermino
    }

    override fun getAula(): String {
        return "- Nome matéria: ${materia.getNomeMateria()}\n" +
                "- Hora início: $horarioInicio\n" +
                "- Hora término: $horarioTermino\n"
    }


}