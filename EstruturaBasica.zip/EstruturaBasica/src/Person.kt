class Person(//é publica por padrão
    val nome: String, //val é propriedade imutável
    val  idade: Int
)

