interface IAlunos {

    fun addAulas(aula: Aula)

    fun removeAulas(aula: Aula)

    fun addLicoesDeCasa(licao: String)

    fun removeLicoesDeCasa(licao: Int)

    fun getAulas()

    fun getLocoesDeCasa()
}