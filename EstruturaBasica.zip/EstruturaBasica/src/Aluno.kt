class Aluno {

    var nome: String
    var numeroDeAluno: Int

    constructor(nome: String, numeroDeAluno: Int){
        this.nome = nome
        this.numeroDeAluno = numeroDeAluno
    }

    fun equals1(listaAlunos: MutableList<Aluno>, numeroDeAluno: Int): Boolean{
        var ret = false
        for(c in listaAlunos){
            if(c.numeroDeAluno === numeroDeAluno){
                ret = true
            }
        }
        return ret
    }

    fun equals2(listaAlunos: MutableList<Aluno>, numeroDeAluno: Int): Boolean{
        var ret = false
        for(c in listaAlunos){
            if(c.numeroDeAluno.equals(numeroDeAluno)){
                ret = true
            }
        }
        return ret
    }

    fun equals3(listaAlunos: MutableList<Aluno>, aluno: Aluno): Boolean{
        var ret = false
        for(c in listaAlunos){
            if(c === aluno){
                ret = true
            }
        }
        return ret
    }

    fun equals4(listaAlunos: MutableList<Aluno>, aluno: Aluno): Boolean{
        var ret = false
        for(c in listaAlunos){
            if(c.equals(aluno)){
                ret = true
            }
        }
        return ret
    }

}