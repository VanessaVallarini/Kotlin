class Veiculo {

    var marca: String

    var modelo: String

    var anoFabricacao: Int

    var cor: String

    var quilometragem: Int

    constructor(marca: String, modelo: String, anoFabricacao: Int, cor: String, quilometragem: Int){
        this.marca = marca
        this.modelo = modelo
        this.anoFabricacao = anoFabricacao
        this.cor = cor
        this.quilometragem = quilometragem
    }
}