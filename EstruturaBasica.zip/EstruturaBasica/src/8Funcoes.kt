fun main() {

    val double = double(2)
    println(double)

    val double2 = double2(2)
    println(double2)

    println()

    val _byteArray = byteArrayOf(1,2,3,4,5)
    val read =  read(_byteArray)
    println(read)

    println()

    foo(strings = *arrayOf("a", "b", "c"))

    println()

    println(asList(*arrayOf("a", "b", "c")))

    println()

    printHello(null)

    println()

    printHello("Vanessa2")

    println()

    println(findFixPoint())

    println()

    println(lambda("4"))

}

fun double(x: Int): Int {
    return 2 * x
} //4

//sem chaves
fun double2(x: Int): Int = x * 2 //4

fun read(b: ByteArray, off: Int = 0, len: Int = b.size) {
    print("${b[1]} , ")
    print("$off , ")
    print(len)
} //2 , 0 , 5kotlin.Unit

fun foo(vararg strings: String) { //b
    println(strings[1])
}

fun <T> asList(vararg ts: T): List<T> { //[a, b, c]
    val result = ArrayList<T>()
    for (t in ts) // ts is an Array
        result.add(t)
    return result
}

fun printHello(name: String?): Unit { //Hi there!
    if (name != null)
        println("Hello $name")
    else
        println("Hi there!")
}

fun printHello2(name: String?): Unit { //Hello Vanessa
    if (name != null)
        println("Hello $name")
    else
        println("Hi there!")
}

fun findFixPoint(): Double { //0.7390851331706995
    val eps = 1E-10
    var x = 1.0
    while (true) {
        val y = Math.cos(x)
        if (Math.abs(x - y) < eps) return x
        x = Math.cos(x)
    }
}

fun lambda(s: String): Int { return s.toIntOrNull() ?: 0 } //4

