fun main() {

    //criando veículos para adicionar na lista de veículos da concessionária
    var veiculo1: Veiculo = Veiculo("Fiat", "Strada 1.4 Mpi Fire Flex 8v Cs", 2005, "Branco", 29000)
    var veiculo2: Veiculo = Veiculo("Chevrolet", "Celta Spirit/ Lt 1.0 Mpfi 8v Flexp. 5p", 2013, "Preto", 80877)
    var veiculo3: Veiculo = Veiculo("Renault", "Sandero Stepway Hi-flex 1.6 16v 5p Aut.", 2012, "Prata", 81432)

    //adicionando os veílos no estoque da concessionária
    var concessionaria1: Concessionaria = Concessionaria()
    concessionaria1.incluirVeiculoEstoque(veiculo1)
    concessionaria1.incluirVeiculoEstoque(veiculo2)
    concessionaria1.incluirVeiculoEstoque(veiculo3)

    println("ESTOQUE")
    concessionaria1.listarVeiculosEstoque()
    println()

    println("VENDAS REGISTRADAS")
    var cliente1: Cliente = Cliente("Vanessa", "Ichikawa", "vanessa@gmail.com", "11964089495", "1165656565")
    var venda1: Venda = Venda(80000.00, veiculo1, cliente1)
    concessionaria1.registrarVenda(veiculo1, cliente1, venda1.valor)
    concessionaria1.vendasRegistradas()
    println()

    println("ESTOQUE ATUALIZADO")
    concessionaria1.listarVeiculosEstoque()
}