class Tripe {

    private var dobrado: Boolean = false

    private var alturaMinima: Int = 0

    private var alturaMaxima: Int = 0

    private var alturaAtual: Int = 0

    constructor(alturaMinima: Int, alturaMaxima: Int){
        this.alturaMinima = alturaMinima
        this.alturaMaxima = alturaMaxima
    }

    fun definirAltura(novaAltura: Int){
        alturaAtual = novaAltura
    }

    fun dobrar(){
        dobrado = true
    }

    fun desdobrar(){
        dobrado = false
    }

    fun guardar(){
        this.dobrar()
        alturaAtual = alturaMinima
    }

    fun prontoParaGuardar(): Boolean{
        if(dobrado == true && alturaAtual == alturaMinima){
            return true
        }
        return false
    }

    fun usar(){
        this.desdobrar()
        alturaAtual = alturaMaxima
    }

    fun prontoParaUsar(): Boolean{
        if(dobrado == false && alturaAtual == alturaMaxima){
            return true
        }
        return false
    }
}