class Casa(cor: String, vagasGaragem: Int) {

    //private var cor: String = cor

    //private var vagasGaragem: Int = vagasGaragem

    private var cor: String

    private var vagasGaragem: Int

    //inicializando as propriedades do objeto
    init{
        this.cor = cor
        this.vagasGaragem = vagasGaragem
    }

    fun setCor(cor: String){
        this.cor = cor
    }

    fun setVagasGaragem(vagasGaragem: Int){
        this.vagasGaragem = vagasGaragem
    }

    override fun toString(): String {
        return "Cor: $cor , Vagas Garagem: $vagasGaragem"
    }

}