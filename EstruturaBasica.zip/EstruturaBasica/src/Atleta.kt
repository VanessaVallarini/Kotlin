class Atleta {

    private var nome: String = ""

    private var nivel: Int = 0

    private var energia: Int = 0

    constructor(nome: String, nivel: Int, energia: Int){
        this.nome = nome
        this.nivel = nivel
        this.energia = energia
    }

    fun getNivel(): Int{
        return nivel
    }

    fun getEnergia(): Int{
        return energia
    }
}