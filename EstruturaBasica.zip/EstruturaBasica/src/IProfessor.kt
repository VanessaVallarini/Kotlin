interface IProfessor {

    fun atribuirAulas(aula: Aula)

    fun removerAulas(aula: Aula)

    fun tornarDocente(aula: Aula)

    fun deixarDeSerDocente()

    fun getAulas()
}