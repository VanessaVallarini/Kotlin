fun main(){

    //Aritméticas

    val maior = 1 > 2
    val menor = 1 < 2
    val ee = maior && menor

    val igual = 1 == 2
    val maiorIgual = 1 >= 2
    val ou = igual || maiorIgual

    val menorIgual = 1 <= 2
    val nao = !menorIgual

    //retorna true se as duas avaliações forem verdadeiras
    println("&&: 1 > 2 && 1 < 2         = " + ee)

    //retorna true se uma das duas avaliações for verdadeira
    println("||: 1 == 2 ||  1 >= 2      = " + ou)

    //retorna o oposto ao resultado da avaliação
    println("!: !menorIgual             = " + nao)
}