interface IAula {

    fun getAula(): String
}