import java.util.*
import kotlin.collections.ArrayList

class Concessionaria {

    var veiculos : ArrayList<Veiculo> = ArrayList()

    var veiculosVendidos : ArrayList<Veiculo> = ArrayList()

    var compradores : ArrayList<Cliente> = ArrayList()

    var valorVenda : ArrayList<Double> = ArrayList()

    var qtdVendas: Int = 0

    fun incluirVeiculoEstoque(veiculo: Veiculo){
        veiculos.add(veiculo)
    }

    fun listarVeiculosEstoque(){

        var count = 0

        while (count != veiculos.size){
            println("Veículo [$count]: " +
                    "Marca: ${veiculos[count].marca} " +
                    "| Modelo: ${veiculos[count].modelo} " +
                    "| Ano: ${veiculos[count].anoFabricacao} " +
                    "| Cor: ${veiculos[count].cor}" +
                    "| Quilometragem: ${veiculos[count].quilometragem}")
            ++count
        }
    }

    fun registrarVenda(veiculo: Veiculo, cliente: Cliente, valor: Double){
        veiculos.remove(veiculo)
        veiculosVendidos.add(veiculo)
        compradores.add(cliente)
        valorVenda.add(valor)
        qtdVendas += 1
    }

    fun vendasRegistradas(){
        var count = 0

        while (count != qtdVendas){
            println("Veículo [$count]: " +
                    "Marca: ${veiculosVendidos[count].marca} " +
                    "| Modelo: ${veiculosVendidos[count].modelo} " +
                    "| Ano: ${veiculosVendidos[count].anoFabricacao} " +
                    "| Cor: ${veiculosVendidos[count].cor}" +
                    "| Quilometragem: ${veiculosVendidos[count].quilometragem}\n" +
                    "Cliente [$count]: " +
                    "| Nome: ${compradores[count].nome} " +
                    "| Sobrenome: ${compradores[count].sobrenome} " +
                    "| Email: ${compradores[count].email} " +
                    "| Celular: ${compradores[count].celular} " +
                    "| Telefone: ${compradores[count].telefone}\n" +
                    "Valor venda: ${valorVenda[count].toString()}"
            )
            ++count
        }
    }
}
