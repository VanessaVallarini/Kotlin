class JogadorDeFutebol {

    private var nome: String = ""

    private var energia: Int = 0

    private var alegria: Int = 0

    private var gols: Int = 0

    private var experiencia: Int = 0

    constructor(nome: String){
        this.nome = nome
    }

    fun fazerGol(){
        energia -= 5
        alegria += 10
        gols += 1
        println("GOOOOL!")
    }

    fun correr(){
        energia -= 10
        println("Cansei")
    }

    fun setExperiencia(){
        var experienciaAnterior = experiencia
        experiencia += 1
        println("Experiencia anterior: $experienciaAnterior \n" +
                "Experiência atual: $experiencia")
    }
}