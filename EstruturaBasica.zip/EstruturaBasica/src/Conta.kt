class Conta {

    private var conta: Int

    private var saldo: Double

    private var titular: Client

    constructor(conta: Int, saldo: Double, titular: Client){
        this.conta = conta
        this.saldo = saldo
        this.titular = titular
    }

    fun deposito(valor: Double): String{
        var valorAnterior = this.saldo
        this.saldo += valor
        return "Tipo de transação: Depósito " +
                "\nValor depositado: R$ " + String.format("%.2f", valor) +
                "\nSaldo anterior da conta: R$ " + String.format("%.2f", valorAnterior) +
                "\nSaldo atual da conta: R$ " + String.format("%.2f", this.saldo)
    }

    fun saque(valor: Double): String{

        if(valor > this.saldo){
            return "Saldo insuficiente."
        }
        else {
            var valorAnterior = this.saldo
            this.saldo -= valor
            return "Tipo de transação: Saque " +
                    "\nValor depositado: R$ " + String.format("%.2f", valor) +
                    "\nSaldo anterior da conta: R$ " + String.format("%.2f", valorAnterior) +
                    "\nSaldo atual da conta: R$ " + String.format("%.2f", this.saldo)
        }
    }
}