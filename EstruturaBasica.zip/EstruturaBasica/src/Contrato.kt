class Contrato: Imprimivel {

    override var nome: String
    override var tipoDocumento: String

    constructor(nome: String, tipoDocumento: String){
        this.nome = nome
        this.tipoDocumento = tipoDocumento
    }

    override fun imprimir(): String{
        return "Nome doc: $nome | Tipo doc: $tipoDocumento | O que é: Eu sou um contrato muito legal"
    }
}