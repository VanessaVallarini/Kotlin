class Client {

    private var nome: String

    private var sobrenome: String

    constructor(nome: String, sobrenome: String){
        this.nome = nome
        this.sobrenome = sobrenome
    }
}