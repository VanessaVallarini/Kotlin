class Casa2 {

    //private var cor: String = cor

    //private var vagasGaragem: Int = vagasGaragem

    private var cor: String

    private var vagasGaragem: Int

    //inicializando as propriedades do objeto
    constructor(cor: String, vagasGaragem: Int){
        this.cor = cor
        this.vagasGaragem = vagasGaragem
    }

    override fun toString(): String {
        return "Cor: $cor , Vagas Garagem: $vagasGaragem"
    }

}