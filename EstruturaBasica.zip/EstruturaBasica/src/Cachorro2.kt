class Cachorro2: Animal2() {

    override fun racaAnimal(raca: String){
        println("Sobrescrita do método abstrato")
    }
}