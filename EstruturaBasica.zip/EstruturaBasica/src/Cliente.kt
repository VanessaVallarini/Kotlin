class Cliente {

    var nome: String

    var sobrenome: String

    var email: String

    var celular: String

    var telefone: String

    constructor(nome: String, sobrenome: String, email: String, celular: String, telefone: String){
        this.nome = nome
        this.sobrenome = sobrenome
        this.email = email
        this.celular = celular
        this.telefone = telefone
    }
}