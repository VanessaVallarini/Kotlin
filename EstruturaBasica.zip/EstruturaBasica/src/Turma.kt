class Turma {

    private var nome: String
    private var curso: Curso

    constructor(nome: String, curso: Curso){
        this.nome = nome
        this.curso = curso
    }

    fun toStrin(): String{
        return "Nome turma            : ${nome}\n" +
                "Curso: ${curso.toStrin()}"
    }
}