fun main(){
    foo()
    println()
    foo5()
    println()
    foo2()
    println()
    foo3()
    println()
    foo4()
    println()
    foo6()
    foo7()
    foo8()
}

//retorno 12
fun foo() {
    listOf(1, 2, 3, 4, 5).forEach {
        if (it == 3) return
        print(it)
    }
}

//retorno 12Fim5
fun foo5() {
    run loop@{
        listOf(1, 2, 3, 4, 5).forEach {
            if (it == 3) return@loop
            print(it)
        }
    }
    print("Fim5")
}

//retorno 1245Fim2
fun foo2() {
    listOf(1, 2, 3, 4, 5).forEach lit@{
        if (it == 3) return@lit
        print(it)
    }
    print("Fim2")
}

//retorno 1245Fim3
fun foo3() {
    listOf(1, 2, 3, 4, 5).forEach {
        if (it == 3) return@forEach
        print(it)
    }
    print("Fim3")
}

//retorno 1245Fim4
fun foo4() {
    listOf(1, 2, 3, 4, 5).forEach(fun(value: Int) {
        if (value == 3) return
        print(value)
    })
    print("Fim4")
}

fun foo6(){
    val _arrayList = arrayListOf<String>("Java", "Kotlin")
    _arrayList.add("Swift")
    for(c in _arrayList){
        print("$c ,")
    }
    println()
}

fun foo7(){
    val _arrayList = arrayListOf<String>("Java", "Kotlin", "Swift")
    _arrayList.forEach(fun(value: String){
        if (value == "Java") return
        print("$value ,")
    })
}

fun foo8(){
    var x = 2
    println()
    while(x > 0){
        print(x)
        x--
    }
    println()
}

