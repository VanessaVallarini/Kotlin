fun main(){
    //val pode ser definida uma única vez. Não é possível mudar o valor dela posteriormente no programa
    val _int = 1 //Declaração de tipo implícita
    val _int2 : Int = 15
    val _long : Long =  314159265359
    val _float : Float = 3.14159265359f //Se esse valor contiver mais de 6 a 7 dígitos decimais, ele será arredondado
    val _double : Double = 3.14159265359
    val _string : String = "Vanessa"
    val _char : Char = 'T'
    val _boolean : Boolean = true
    val _arrayList = arrayListOf<String>("Java", "Kotlin")
    _arrayList.add("Swift")
    val _byte : Byte = 1

    //Constantes literais
    val oneMillion = 1_000_000
    val creditCardNumber = 1234_5678_9012_3456L
    val socialSecurityNumber = 999_99_9999L
    val hexBytes = 0xFF_EC_DE_5E
    val bytes = 0b11010010_01101001_10010100_10010010


    println(_int)
    println(_int2)
    println(_long)
    println(_float)
    println(_double)
    println(_string)
    println(_char)
    println(_boolean)
    println(_arrayList)
    println(_byte)
    println(oneMillion)
    println(creditCardNumber)
    println(socialSecurityNumber)
    println(hexBytes)
    println(bytes)

}

