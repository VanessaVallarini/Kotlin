interface ICurso {

    fun addAulas(aula: Aula)

    fun removeAulas(aula: Aula)

    fun addAlunos(alunos: Alunos)

    fun removeAlunos(alunos: Alunos)
}