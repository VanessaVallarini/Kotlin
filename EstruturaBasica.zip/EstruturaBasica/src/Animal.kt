open class Animal {

    private var nomeDoAnimal: String
    public var nomeDoAnimal2: String = "nome público"
    protected var idade: Int
    internal open val propriedadeSobrescrita : Int = 0

    constructor(nomeDoAnimal : String, idade: Int){
        this.nomeDoAnimal = nomeDoAnimal
        this.idade = idade
    }

    //permite a sobrescrita
    open fun getAnimal(): String{
        return("Nome: $nomeDoAnimal \n" +
                getIdadeDoAnimal())
    }

    //não permite a sobrescrita
    final fun getIdadeDoAnimal(): String{
        return("Idade: $idade")
    }

    override fun toString(): String{
        return "Nome: ${nomeDoAnimal} \n" +
                "Idade: ${idade}"
    }


}