class Cachorro : Animal{

    var raca : String
    override val propriedadeSobrescrita : Int = 4
    //override var nomeDoAnimal: String = "teste" -> Como não está marcada como open não posso sobrescrever essa propriedade

    constructor(raca: String, nomeDoAnimal: String, idade: Int) : super(nomeDoAnimal, idade) {
        this.raca = raca
    }

    //sobrescritsa do método da classe mãe
    override fun getAnimal(): String {
        return "${super.getAnimal()} \n" +
                "Raça: $raca \n" +
                "Propriedade sobrescrita: $propriedadeSobrescrita"
    }

    //fazendo referência às propriedades da classe mãe
    fun getAnimal2(): String {
        return "Nome: ${super.nomeDoAnimal2} \n" +
                "Idade: ${super.idade} \n" +
                "Raça: $raca \n" +
                "Propriedade sobrescrita: $propriedadeSobrescrita"
    }

}