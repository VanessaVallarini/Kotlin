class Professor: IProfessor {

    private var nome: String
    private var rd: Int
    private var isDocente: Boolean = false
    private var fazChamada: Boolean = false
    private var listaDeAulas: MutableList<Aula> = mutableListOf()

    constructor(nome: String, rd: Int){
        this.nome = nome
        this.rd = rd
    }

    constructor(nome: String, rd: Int, aulas: Aula){
        this.nome = nome
        this.rd = rd
        this.isDocente = true
        this.fazChamada = true
        this.listaDeAulas.add(aulas)
    }

    override fun atribuirAulas(aula: Aula) {
        listaDeAulas.add(aula)
    }

    override fun removerAulas(aula: Aula) {
        listaDeAulas.remove(aula)
    }

    override fun tornarDocente(aula: Aula) {
        this.isDocente = true
        this.fazChamada = true
        listaDeAulas.add(aula)
    }

    override fun deixarDeSerDocente() {
        this.isDocente = false
        this.fazChamada = false
        listaDeAulas.clear()
    }

    override fun getAulas() {
        println("Aulas:")
        for(a in listaDeAulas){
            println(a.getAula())
        }
    }

    override fun toString(): String{
        if(isDocente){
            return "Nome: ${nome}\n" +
                    "RD: ${rd}\n" +
                    "Docente: Sim\n" +
                    "Realiza chamada: Sim"
        } else{
            return "Nome: ${nome}\n" +
                    "RD: ${rd}\n"
        }
    }
}