class Materia: IMateria {

    private var nome: String

    constructor(nome: String){
        this.nome = nome
    }

    override fun getNomeMateria(): String{
        return nome
    }
}