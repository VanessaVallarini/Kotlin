fun main(){

    var cachorro : Cachorro2 = Cachorro2()
    cachorro.racaAnimal("Poodle")
}