interface IMateria {

    fun getNomeMateria(): String
}