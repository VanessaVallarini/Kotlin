public final data class Coca(val tamanho: Int, val preco: Double) {


    fun equals(other: Int): Boolean{
        return this.tamanho === other
    }

    fun hashCode(coca2: Coca): Int{
        return coca2.hashCode()
    }

    override fun toString(): String{
        return "Tamanho: ${this.tamanho}\n" +
                "Preço: ${this.preco}"
    }
}