fun main(){

    println("Adicionando objetos para impressão.......")
    var foto: Foto = Foto("Foto", "Foto")
    println(foto.imprimir())

    var documento: Documento = Documento("Documento", "Documento")
    println(documento.imprimir())

    var contrato: Contrato = Contrato("Contrato", "Contrato")
    println(contrato.imprimir())

    var impressora: Impressora = Impressora()
    impressora.addImprimivel(foto)
    impressora.addImprimivel(documento)
    impressora.addImprimivel(contrato)

    println()
    println("Imprimindo...............................")
    impressora.imprimirListaImprimivel()
}