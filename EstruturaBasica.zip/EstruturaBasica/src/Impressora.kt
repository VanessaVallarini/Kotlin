class Impressora {

    var listaImprimivel: MutableList<Imprimivel> = mutableListOf()

    fun addImprimivel(imprimivel: Imprimivel){
        listaImprimivel.add(imprimivel)
    }

    fun imprimirListaImprimivel(){

        for(i in listaImprimivel){
            println("Nome: ${i.nome} | Tipo Impressão: ${i.tipoDocumento}")
        }
    }

}