class Bichinho : Saudavel {

    override var diagnostico: String = "saudavel"

    override fun animalSaudavel(): Boolean{
        return true
    }

    //função implementada
    fun tomarMedicamento(){
        if(!animalSaudavel()){
            println("O animal deve tomar medicamentos")
        }else{
            println("O animal não precisa tomar medicamentos")
        }
    }

}