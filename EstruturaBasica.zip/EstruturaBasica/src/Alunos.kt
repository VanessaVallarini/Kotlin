class Alunos: IAlunos {

    private var ra: Int
    private var nome: String
    private var sobrenome: String
    private var listaAulas: MutableList<Aula> = mutableListOf()
    private var listaLicoesDeCasa: MutableList<String> = mutableListOf()

    constructor(ra: Int, nome: String, sobrenome: String){
        this.ra = ra
        this.nome = nome
        this.sobrenome = sobrenome
    }

    override fun addAulas(aula: Aula) {
        listaAulas.add(aula)
    }

    override fun removeAulas(aula: Aula) {
        listaAulas.remove(aula)
    }

    override fun addLicoesDeCasa(licao: String) {
        listaLicoesDeCasa.add(licao)
    }

    override fun removeLicoesDeCasa(licao: Int) {
        listaLicoesDeCasa.removeAt(licao)
    }

    override fun toString(): String{
        return "RA:    ${ra}\n" +
                "Nome: ${nome} ${sobrenome}\n"
    }

    override fun getAulas(){
        println("Aulas:")
        for(a in listaAulas){
            println(a.getAula())
        }
    }

    override fun getLocoesDeCasa(){
        println("Lições de casa:")
        for(l in listaLicoesDeCasa){
            println("- ${l}")
        }
    }

}