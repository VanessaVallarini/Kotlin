interface Saudavel {

    //propriedade
    var diagnostico: String

    //função abstrata
    fun animalSaudavel(): Boolean
}