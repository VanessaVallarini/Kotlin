class Curso: ICurso{

    private var nome: String
    private var professorResponsavel: Professor
    private var listaDeAulas: MutableList<Aula> = mutableListOf()
    private var listaDeAlunos: MutableList<Alunos> = mutableListOf()

    constructor(nome: String, professorResponsavel: Professor){
        this.nome = nome
        this.professorResponsavel = professorResponsavel
    }

    override fun addAulas(aula: Aula) {
        listaDeAulas.add(aula)
    }

    override fun removeAulas(aula: Aula) {
        listaDeAulas.remove(aula)
    }

    override fun addAlunos(alunos: Alunos) {
        listaDeAlunos.add(alunos)
    }

    override fun removeAlunos(alunos: Alunos) {
        listaDeAlunos.remove(alunos)
    }

    fun toStrin(): String{
        return "Nome curso            : ${nome}\n" +
                "Professor responsável: ${professorResponsavel}"
    }
}