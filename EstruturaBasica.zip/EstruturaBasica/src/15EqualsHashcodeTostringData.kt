fun main(){

    //equal: comparação entre objetos e strings
    println("Equals----------------------------------------------")

    var um = "Um"
    var um2 = "Um"
    val _arrayList1 = arrayListOf<String>("Java", "Kotlin")
    val _arrayList2 = arrayListOf<String>("Java", "Kotlin")

    if(um === um2){
        println(true) //true
    } else{
        println(false)
    }


    if(um.equals(um2)){ //true
        println(true)
    } else{
        println(false)
    }


    if(_arrayList1 === _arrayList2) { //false
        println(true)
    } else{
        println(false)
    }

    if(_arrayList1.equals(_arrayList2)) { //true
        println(true)
    } else{
        println(false)
    }

    println()
    //HashCode: retorna um valor de código de hash para o objeto
    println("HashCode--------------------------------------------")
    println(_arrayList1.hashCode())
    println(_arrayList2.hashCode())

    println()
    //ToString: retorna uma representação string do objeto
    println("ToString--------------------------------------------")
    var animal: Animal = Animal("Dog", 4)
    println(animal.toString())

    println()
    //Data Classes: classes que tem como objetivo principal armazenar dados
    //altomaticamente implementa as funções equals(), hashcode() e toString()
    println("DataClasses-----------------------------------------")
    data class User(val  name: String, val age: Int)
    var user: User = User("Van", 30)
    var user2: User = User("Van", 30)
    if(user.equals(user2)) println("User1 é igual user2? : "+ true) else println(false)
    if(user === user2) println("User1 é igual user2? : "+ true) else println(false)
    println("HashCode user1: " + user.hashCode())
    println("HashCode user2: " + user2.hashCode())
    println("User2 toString(): " + user2.toString())

    println()
    //Exercícios
    println("Exercícios------------------------------------------")
    var pessoa1: Pessoa = Pessoa("Van", 12345678)
    var pessoa2: Pessoa = Pessoa("Van", 12345678)
    //comparamdo pessoas
    println("As pessoas são iguais? " + pessoa1.equals(pessoa2))
    //comparando o rg
    println("O RG das pessoas são iguais? " + pessoa1.rg.equals(pessoa2.rg))
    //hash
    println("Hash da pessoa 1: " + pessoa1.hashCode())
    println("Hash da pessoa 2: " + pessoa2.hashCode())
    //to string
    println(pessoa1.toString())
    println(pessoa2.toString())

    println()

    var coca1: Coca = Coca(5, 6.99)
    var coca2: Coca = Coca(5, 6.99)
    //comparamdo cocas
    println("As cocas são iguais? " + coca1.equals(coca2)) //como eu não sobrescrevi o equals dá true
    //comparando o tamanho
    println("O tamanho das cocas são iguais? " + coca1.equals(coca2.tamanho))
    //hash
    println("Hash da coca 1: " + coca1.hashCode())
    println("Hash da coca 2: " + coca2.hashCode())
    //to string
    println(coca1.toString())
    println(coca2.toString())

    println()

    var aluno1: Aluno = Aluno("Vanessa", 12345)
    var aluno2: Aluno = Aluno("Fábio", 54321)
    var aluno3: Aluno = Aluno("Dani", 56789)
    var aluno4: Aluno = Aluno("Camila", 98765)
    var listaAlunos: MutableList<Aluno> = mutableListOf()
    listaAlunos.add(aluno1)
    listaAlunos.add(aluno2)
    listaAlunos.add(aluno3)
    listaAlunos.add(aluno4)
    var aluno5: Aluno = Aluno("Camila", 98765)
    if(listaAlunos.contains(aluno5)) println("O número do aluno contém na lista? contains : " + true) else println("O número do aluno contém na lista? contains : " + false)
    var ret1 = aluno4.equals1(listaAlunos, aluno5.numeroDeAluno)
    println("O número do aluno contém na lista? === : " + ret1)
    var ret2 = aluno4.equals2(listaAlunos, aluno5.numeroDeAluno)
    println("O número do aluno contém na lista? equals : " + ret2)
    var ret3 = aluno4.equals3(listaAlunos, aluno5)
    println("O aluno contém na lista? === : " + ret3)
    var ret4 = aluno4.equals4(listaAlunos, aluno5)
    println("O aluno contém na lista? equals : " + ret4)

    println()

    var funcionario1: Funcionario = Funcionario("Vanessa", 12345)
    var funcionario2: Funcionario = Funcionario("Fábio", 54321)
    var funcionario3: Funcionario = Funcionario("Dani", 56789)
    var funcionario4: Funcionario = Funcionario("Camila", 98765)

    var listaFuncionarios: MutableList<Funcionario> = mutableListOf()
    listaFuncionarios.add(funcionario1)
    listaFuncionarios.add(funcionario2)
    listaFuncionarios.add(funcionario3)
    listaFuncionarios.add(funcionario4)

    var funcionario5: Funcionario = Funcionario("Camila", 98765)

    var result = if(listaFuncionarios.contains(funcionario5)) true else false
    println("O funcionário contém na lista? contains : " + result)

    var retFunc1 = funcionario4.equals1(listaFuncionarios, funcionario5.numeroDeRegistro)
    println("O número de registro do Funcionário contém na lista? === : " + retFunc1)

    var retFunc2 = funcionario4.equals2(listaFuncionarios, funcionario5.numeroDeRegistro)
    println("O número de registro do Funcionário contém na lista? equals : " + retFunc2)

    var retFunc3 = funcionario4.equals3(listaFuncionarios, funcionario5)
    println("O Funcionário contém na lista? === : " + retFunc3)

    var retFunc4 = funcionario4.equals4(listaFuncionarios, funcionario5)
    println("O Funcionário contém na lista? equals : " + retFunc4)
}