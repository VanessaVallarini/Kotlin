abstract class Animal2 {
    //não permite instâncias e servem se modelo para classes derivadas
    //as classes filhas devem reescrever a função da classe abstrata
    abstract fun racaAnimal(raca: String);

}