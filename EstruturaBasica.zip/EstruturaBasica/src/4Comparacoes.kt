fun main(){

    //Aritméticas

    var maior = 1 > 2
    var menor = 1 < 2
    var igual = 1 == 2
    var maiorIgual = 1 >= 2
    var menorIgual = 1 <= 2
    var diferente = 1 != 2

    println("Maior: 1 > 2 =              " + maior)
    println("Menor: 1 < 2 =              " + menor)
    println("Igual: 1 == 2 =             " + igual)
    println("Maior ou Igual: 1 >= 2 =    " + maiorIgual)
    println("Menor ou Igual: 1 <= 2 =    " + menorIgual)
    println("Diferente: 1 != 2 =         " + diferente)
}