/**
* Programa que implementa aulas para diferentes tipos de habitações.
* Mostra como:
* Crie hierarquia de classes, variáveis e funções com herança,
* classe abstrata, substituição e variáveis privadas vs. públicas.
*/
fun main(){
    val squareCabin = SquareCabin(6, 50.0)

    //println("\nSquare Cabin\n============")
    //println("Capacity: ${squareCabin.capacity}")
    //println("Material: ${squareCabin.buildingMaterial}")
    //println("Has room? ${squareCabin.hasRoom()}")

    //evite termos que escrever squareCabin.
    with(squareCabin) {
        println("\nSquare Cabin\n============")
        println("Capacity: ${capacity}")
        println("Material: ${buildingMaterial}")
        println("Has room? ${hasRoom()}")
        println("Floor area: ${floorArea()}")
    }

    val roundHut = RoundHut(3, 10.0)

    with(roundHut) {
        println("\nRound Hut\n=========")
        println("Material: ${buildingMaterial}")
        println("Capacity: ${capacity}")
        println("Has room? ${hasRoom()}")
        println("Floor area: ${floorArea()}")
        println("Has room? ${hasRoom()}")
        getRoom()
        println("Has room? ${hasRoom()}")
        getRoom()
        println("Carpet size: ${calculateMaxCarpetSize()}")
    }

    val roundTower = RoundTower(4, 15.5)

    with(roundTower) {
        println("\nRound Tower\n==========")
        println("Material: ${buildingMaterial}")
        println("Capacity: ${capacity}")
        println("Has room? ${hasRoom()}")
        println("Floor area: ${floorArea()}")
        println("Carpet size: ${calculateMaxCarpetSize()}")
    }
}