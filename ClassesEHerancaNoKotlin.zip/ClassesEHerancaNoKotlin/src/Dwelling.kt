/**
* Define propriedades comuns a todas as moradias.
* Todas as moradias têm espaço no chão,
* mas seu cálculo é específico para a subclasse.
* Verificar e obter uma sala são implementados aqui
* porque são iguais para todas as subclasses de Habitação.
*
* @param residentes Número atual de residentes
*/
abstract class Dwelling(private var residents: Int){
    abstract val buildingMaterial: String //materiais para construção
    abstract val capacity: Int //capacidade de moradores

    /**
    * Verifica se há lugar para outro residente.
    *
    * @return true se quarto disponível, false caso contrário
    */
    fun hasRoom(): Boolean {
        return residents < capacity
    }

    /**
    * Calcula a área útil da habitação.
    * Implementado por subclasses onde a forma é determinada.
    *
    * @return floor area
    */
    abstract fun floorArea(): Double

    /**
    * Compara a capacidade com o número de residentes e
    * se a capacidade for maior que o número de residentes,
    * adicionar residente aumentando o número de residentes.
    * Imprima o resultado.
    */
    fun getRoom() {
        if (capacity > residents) {
            residents++
            println("You got a room!")
        } else {
            println("Sorry, at capacity and no rooms left.")
        }
    }
}