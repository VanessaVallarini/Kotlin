import kotlin.math.PI
import kotlin.math.sqrt

/**
* Habitação com piso circular
*
* @param residentes Número atual de residentes
* @param radius Radius
*/
open class RoundHut(residents: Int, val radius: Double) : Dwelling(residents) {
    override val buildingMaterial = "Straw"
    override val capacity = 4

    /**
    * Calcula a área do piso para uma habitação redonda.
    *
    * @return floor area
    */
    override fun floorArea(): Double {
        return PI * radius * radius
    }

    /**
    * Calcula o comprimento máximo para um tapete quadrado
    * que se ajusta ao piso circular.
    *
    * @return comprimento do tapete
    */
    fun calculateMaxCarpetSize(): Double {
        val diameter = 2 * radius
        return sqrt(diameter * diameter / 2)
    }
}