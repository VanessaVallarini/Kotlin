/**
* Uma cabana quadrada.
*
* @param residentes Número atual de residentes
* @param length Length
*/
class SquareCabin(residents: Int, val length: Double) : Dwelling(residents){
    override val buildingMaterial = "Wood"
    override val capacity = 6

    /**
    * Calcula a área do piso de uma casa quadrada.
    *
    * @return floor area
    */
    override fun floorArea(): Double {
        return length * length
    }
}