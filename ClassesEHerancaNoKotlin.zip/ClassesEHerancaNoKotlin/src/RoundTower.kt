import kotlin.math.PI

/**
* Torre redonda com vários andares.
*
* @param residentes Número atual de residentes
* @param radius Radius
* @param andares Número de histórias
*/
class RoundTower(residents: Int, radius: Double, val floors: Int = 2) : RoundHut(residents, radius) {

    override val buildingMaterial = "Stone"

    // A capacidade depende do número de andares.
    override val capacity = 4 * floors

    /**
    * Calcula a área total do piso para uma residência em torre
    * com várias histórias.
    *
    * @return floor area
    */
    override fun floorArea(): Double {
        return super.floorArea() * floors
    }
}